const menuToggle=document.getElementById("menuToggle");
const navLinks=document.getElementById("navLinks");
menuToggle.addEventListener("click",()=>navLinks.classList.toggle("show"));
navLinks.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>navLinks.classList.remove("show")));

const filters=document.querySelectorAll(".filter");
const cards=document.querySelectorAll(".product-card");
filters.forEach(btn=>btn.addEventListener("click",()=>{
  filters.forEach(x=>x.classList.remove("active"));
  btn.classList.add("active");
  const category=btn.dataset.filter;
  cards.forEach(card=>{
    card.style.display=category==="all"||card.dataset.category===category?"":"none";
  });
}));

const modal=document.getElementById("productModal");
const modalImage=document.getElementById("modalImage");
const modalTitle=document.getElementById("modalTitle");
const modalDesc=document.getElementById("modalDesc");
document.querySelectorAll(".details-btn").forEach(btn=>btn.addEventListener("click",()=>{
  modalTitle.textContent=btn.dataset.name;
  modalDesc.textContent=btn.dataset.desc;
  modalImage.src=btn.dataset.img;
  modal.classList.add("open");
  modal.setAttribute("aria-hidden","false");
}));
function closeModal(){modal.classList.remove("open");modal.setAttribute("aria-hidden","true");}
document.getElementById("modalClose").addEventListener("click",closeModal);
document.getElementById("modalBackdrop").addEventListener("click",closeModal);
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal();});
document.getElementById("modalContact").addEventListener("click",closeModal);
