MEGA APPLE — DEMO WEBSITE

Ishga tushirish:
1. ZIP faylni oching.
2. index.html faylini Chrome yoki boshqa brauzerda oching.
3. Rasmlar va shriftlar internet orqali yuklanadi.

Loyiha ichida:
- index.html
- style.css
- script.js

Eslatma:
Bu Apple uslubidagi mustaqil demo vitrina. Rasmiy Apple sayti emas.
iPhone 18 Duo bo‘limi rasmiy mahsulot emas, kreativ konsept sifatida berilgan.
Narxlar namuna tariqasida ko‘rsatilgan.
